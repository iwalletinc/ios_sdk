//
//  IWalletApi.h
//  IWalletApi
//
//  Created by Eugene Kus on 27.05.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for IWalletApi.
FOUNDATION_EXPORT double IWalletApiVersionNumber;

//! Project version string for IWalletApi.
FOUNDATION_EXPORT const unsigned char IWalletApiVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IWalletApi/PublicHeader.h>


