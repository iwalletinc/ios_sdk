//
//  iWalletScannerManager.h
//  iWalletScannerManager
//
//  Created by Eugene Kus on 20.05.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for iWalletScannerManager.
FOUNDATION_EXPORT double iWalletScannerManagerVersionNumber;

//! Project version string for iWalletScannerManager.
FOUNDATION_EXPORT const unsigned char iWalletScannerManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iWalletScannerManager/PublicHeader.h>


