//
//  iWalletScannerSDK.h
//  iWalletScannerSDK
//
//  Created by Eugene Kus on 31.01.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for iWalletScannerSDK.
FOUNDATION_EXPORT double iWalletScannerSDKVersionNumber;

//! Project version string for iWalletScannerSDK.
FOUNDATION_EXPORT const unsigned char iWalletScannerSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iWalletScannerSDK/PublicHeader.h>


